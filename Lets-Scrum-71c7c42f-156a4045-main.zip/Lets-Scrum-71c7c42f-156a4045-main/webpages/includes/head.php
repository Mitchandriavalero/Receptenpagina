    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/navfoot.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-9lF+Nu6E3rV7lI6O+U6/BzZOdJ0H0zj1BXeJhE/sH/JFmj+vf8gxoZlCJE7YnQ1T8LFVHhNcxB1ejBg+xJxjw==" crossorigin="anonymous" />
    <link href="../fontawesome-free-6.2.1-web/css/fontawesome.css" rel="stylesheet">
    <link href="../fontawesome-free-6.2.1-web/css/brands.css" rel="stylesheet">
    <link href="../fontawesome-free-6.2.1-web/css/solid.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/63e3b55288.js" crossorigin="anonymous"></script>
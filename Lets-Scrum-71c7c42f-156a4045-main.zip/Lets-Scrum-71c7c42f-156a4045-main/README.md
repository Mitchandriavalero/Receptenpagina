Welkom bij Westich Recepten!

Functies van onze website:
- Bekijk de laatste 6 toegevoegde recepten op de homepagina.
- Bekijk alle recepten op de receptenpagina.
- Filter recepten door middel van de zoekbalk (filters: naam, land van herkomst, soort gerecht).
- Bekijk de details van elk recept (bereidingswijze en ingrediënten) door te klikken op het gewenste recept.
- Verander het aantal personen waarvoor het recept gemaakt gaat worden door het klikken op de < en > tekens. Dit verandert de hoeveelheid ingrediënten naar de juiste hoeveelheid voor dit aantal personen.
- Maak een account aan door te klikken op "Inloggen" en vervolgens "Account aanmaken".
- Wilt u recepten verwijderen of toevoegen aan de website? Log dan in met gebruiksersnaam "admin". Let op: Maak wel eerst een account aan waarbij de gebruiksersnaam admin is. Nu kunt u recepten toevoegen door op de receptenpagina op de "+" te klikken en recepten verwijderen door op de pagina van het recept te klikken op "Verwijder Recept".

Om te beginnen met het gebruiken van onze website download u alle bestanden. Ook is xampp benodigd om onze website de gebruiken. Open xampp en start apache en mysql. Vervolgens gaat u naar phpmyadmin en kopieert u de data uit “recipes.sql” file in de sql query. Hierna kopieert u ook nog de data uit “login.sql” in de sql query. Dit maakt de databases aan met de correcte tabellen. Nu opent u de index.php met xampp of php server en kunt u beginnen met koken!

Heeft u vragen over onze website? Klik dan op een van onze namen in de footer en stuur ons een mail.

Wij hopen dat onze website u van pas komt!

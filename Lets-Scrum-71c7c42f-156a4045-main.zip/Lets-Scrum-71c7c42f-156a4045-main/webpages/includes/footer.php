<footer>
    <div class="footer">
        <p class="footer-text">
            <a href="mailto:170435@student.horizoncollege.nl">Wesley Teubl</a> |
            <a href="mailto:170737@student.horizoncollege.nl">Justin Kroeze</a> |
            <a href="mailto:169063@student.horizoncollege.nl">Jennifer Bot</a> |
            <a href="mailto:140649@student.horizoncollege.nl">Mitch Andria Valero</a>
        </p>
    </div>
</footer>